  CSci 4061 Fall 2017
  Assignment# 3: Piper program for executing pipe commands
  
  Student name: Cole Wallin
  Student ID: 5117843
  
  walli234@umn.edu
  
  Operating system on which you tested your code: Linux
  CSELABS machine: csel-kh4250-04.cselabs.umn.edu, csel-kh4250-22.cselabs.umn.edu
   
   
   
  BUGS:
    - The spacing can be a little off in the logs depending on how long the command is
   
  Not BUGS:
   - The commands still have extra whitespace but the execvp function doesn't execute differently because of it.
     